Place your ministry logo image in the project root or assets folder and name it "logo.png".

Options:
- Put the provided PNG at: ./logo.png  (recommended)
- Or place it in ./assets/logo.png and update the <img> src in index.html and login.html accordingly.

If you want me to embed a different filename or path, tell me the filename and I will update the HTML.
